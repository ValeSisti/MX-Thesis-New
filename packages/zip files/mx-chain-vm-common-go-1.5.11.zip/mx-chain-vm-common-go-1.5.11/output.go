package vmcommon

import (
	"encoding/hex"
	"fmt"
	"math/big"

	"github.com/multiversx/mx-chain-core-go/core/check"
	"github.com/multiversx/mx-chain-core-go/data/vm"
)

// StorageUpdate represents a change in the account storage (insert, update or delete)
// Note: current implementation might also return unmodified storage entries.
type StorageUpdate struct {
	// Offset is the storage key.
	Offset []byte

	// Data is the new storage value.
	// Zero indicates missing data for the key (or even a missing key),
	// therefore a value of zero here indicates that
	// the storage map entry with the given key can be deleted.
	Data []byte

	// Written represents that this storage was change and needs to be persisted
	// into the chain
	Written bool
}

// OutputAccount shows the state of an account after contract execution.
// It can be an existing account or a new account created by the transaction.
// Note: the current implementation might also return unmodified accounts.
type OutputAccount struct {
	// Address is the public key of the account.
	Address []byte

	// Nonce is the new account nonce.
	Nonce uint64

	// Balance is the account balance after running a SC.
	// Only used for some tests now, please ignore. Might be removed in the future.
	Balance *big.Int

	// StorageUpdates is a map containing pointers to StorageUpdate structs,
	// indexed with strings produced by `string(StorageUpdate.Offset)`, for fast
	// access by the Offset of the StorageUpdate. These StorageUpdate structs
	// will be processed by the Node to modify the storage of the SmartContract.
	// Please note that it is likely that not all existing account storage keys
	// show up here.
	StorageUpdates map[string]*StorageUpdate

	// Code is the assembled code of a smart contract account.
	// This field will be populated when a new SC must be created after the transaction.
	Code []byte

	// CodeMetadata is the metadata of the code
	// Like "Code", this field will be populated when a new SC must be created after the transaction.
	CodeMetadata []byte

	// CodeDeployerAddress will be populated in case of contract deployment or upgrade (both direct and indirect)
	CodeDeployerAddress []byte

	// BalanceDelta is by how much the balance should change following the SC execution.
	// A negative value indicates that balance should decrease.
	BalanceDelta *big.Int

	// OutputTransfers represents the cross shard calls for this account
	OutputTransfers []OutputTransfer

	// GasUsed will be populated if the contract was called in the same shard
	GasUsed uint64

	// BytesAddedToStorage for this output account
	BytesAddedToStorage uint64

	// BytesDeletedFromStorage for this output account
	BytesDeletedFromStorage uint64

	// BytesConsumedByTxAsNetworking for this output account
	BytesConsumedByTxAsNetworking uint64
}

// OutputTransfer contains the fields needed to create transfers to another shard
type OutputTransfer struct {
	// Index of the transfer
	Index uint32
	// Value to be transferred
	Value *big.Int
	// GasLimit to used for the call
	GasLimit uint64
	// GasLocked holds the amount of gas to be kept aside for the eventual callback execution
	GasLocked uint64
	// AsyncData to be used in cross call
	AsyncData []byte
	// Data to be used in cross call
	Data []byte
	// CallType is set if it is a smart contract invocation
	CallType vm.CallType
	// SenderAddress is the actual sender for the given output transfer, this is needed when
	// contract A calls contract B and contract B does the transfers
	SenderAddress []byte
}

// LogEntry represents an entry in the contract execution log.
// TODO: document all fields.
type LogEntry struct {
	Identifier []byte
	Address    []byte
	Topics     [][]byte
	Data       [][]byte
}

// VMOutput is the return data and final account state after a SC execution.
type VMOutput struct {
	// ReturnData is the function call returned result.
	// This value does not influence the account state in any way.
	// The value should be accessible in a UI.
	// ReturnData is part of the transaction receipt.
	ReturnData [][]byte

	// ReturnCode is the function call error code.
	// If it is not `Ok`, the transaction failed in some way - gas is, however, consumed anyway.
	// This value does not influence the account state in any way.
	// The value should be accessible to a UI.
	// ReturnCode is part of the transaction receipt.
	ReturnCode ReturnCode

	// ReturnMessage is a message set by the SmartContract, destined for the
	// caller
	ReturnMessage string

	// GasRemaining = VMInput.GasProvided - gas used.
	// It is necessary to compute how much to charge the sender for the transaction.
	GasRemaining uint64

	// GasRefund is how much gas the sender earned during the transaction.
	// Certain operations, like freeing up storage, actually return gas instead of consuming it.
	// Based on GasRefund, the sender could in principle be rewarded instead of taxed.
	GasRefund *big.Int

	// OutputAccounts contains data about all accounts changed as a result of the
	// Transaction. It is a map containing pointers to OutputAccount structs,
	// indexed with strings produced by `string(OutputAccount.Address)`, for fast
	// access by the Address of the OutputAccount.
	// This information tells the Node how to update the account data.
	// It can contain new accounts or existing changed accounts.
	// Note: the current implementation might also retrieve accounts that were not changed.
	OutputAccounts map[string]*OutputAccount

	// DeletedAccounts is a list of public keys of accounts that need to be deleted
	// as a result of the transaction.
	DeletedAccounts [][]byte

	// TouchedAccounts is a list of public keys of accounts that were somehow involved in the VM execution.
	// TODO: investigate what we need to to about these.
	TouchedAccounts [][]byte

	// Logs is a list of event data logged by the vmcommon.
	// Smart contracts can choose to log certain events programatically.
	// There are 3 main use cases for events and logs:
	// 1. smart contract return values for the user interface;
	// 2. asynchronous triggers with data;
	// 3. a cheaper form of storage (e.g. storing historical data that can be rendered by the frontend).
	// The logs should be accessible to the UI.
	// The logs are part of the transaction receipt.
	Logs []*LogEntry
}

// GetFirstReturnData is a helper function that returns the first ReturnData of VMOutput, interpreted as specified.
func (vmOutput *VMOutput) GetFirstReturnData(asType vm.ReturnDataKind) (interface{}, error) {
	if len(vmOutput.ReturnData) == 0 {
		return nil, fmt.Errorf("no return data")
	}

	returnData := vmOutput.ReturnData[0]

	switch asType {
	case vm.AsBigInt:
		return big.NewInt(0).SetBytes(returnData), nil
	case vm.AsBigIntString:
		return big.NewInt(0).SetBytes(returnData).String(), nil
	case vm.AsString:
		return string(returnData), nil
	case vm.AsHex:
		return hex.EncodeToString(returnData), nil
	}

	return nil, fmt.Errorf("can't interpret return data")
}

// GetMaxOutputTransferIndex returns the maximum output transfer index
func (vmOutput *VMOutput) GetNextAvailableOutputTransferIndex() uint32 {
	maxTransferIndex := uint32(0)
	for _, account := range vmOutput.OutputAccounts {
		for _, transfer := range account.OutputTransfers {
			if transfer.Index > maxTransferIndex {
				maxTransferIndex = transfer.Index
			}
		}
	}

	return maxTransferIndex + 1
}

// ReindexTransfers from VMOutput
func (vmOutput *VMOutput) ReindexTransfers(nextIndexProvider NextOutputTransferIndexProvider) error {

	if check.IfNil(nextIndexProvider) {
		return ErrNilTransferIndexer
	}

	reindexed := false
	crtIndex := nextIndexProvider.GetCrtTransferIndex() - 1
	for _, account := range vmOutput.OutputAccounts {
		for transferIdx, transfer := range account.OutputTransfers {
			if transfer.Index == 0 {
				return ErrTransfersNotIndexed
			}
			account.OutputTransfers[transferIdx].Index = transfer.Index + crtIndex
			reindexed = true
		}
	}
	if reindexed {
		nextIndexProvider.SetCrtTransferIndex(vmOutput.GetNextAvailableOutputTransferIndex())
	}

	return nil
}

// MergeOutputAccounts merges the given account into the current one
func (o *OutputAccount) MergeOutputAccounts(outAcc *OutputAccount) {
	if len(outAcc.Address) != 0 {
		o.Address = outAcc.Address
	}

	o.MergeStorageUpdates(outAcc)

	if outAcc.Balance != nil {
		o.Balance = outAcc.Balance
	}
	if o.BalanceDelta == nil {
		o.BalanceDelta = big.NewInt(0)
	}
	if outAcc.BalanceDelta != nil {
		o.BalanceDelta.Add(o.BalanceDelta, outAcc.BalanceDelta)
	}
	if len(outAcc.Code) > 0 {
		o.Code = outAcc.Code
	}
	if len(outAcc.CodeMetadata) > 0 {
		o.CodeMetadata = outAcc.CodeMetadata
	}
	if outAcc.Nonce > o.Nonce {
		o.Nonce = outAcc.Nonce
	}

	lenLeftOutTransfers := len(o.OutputTransfers)
	lenRightOutTransfers := len(outAcc.OutputTransfers)
	if lenRightOutTransfers > lenLeftOutTransfers {
		o.OutputTransfers = append(o.OutputTransfers, outAcc.OutputTransfers[lenLeftOutTransfers:]...)
	}

	o.GasUsed = outAcc.GasUsed

	if outAcc.CodeDeployerAddress != nil {
		o.CodeDeployerAddress = outAcc.CodeDeployerAddress
	}
}

// MergeStorageUpdates will copy all the storage updates from the given output account
func (o *OutputAccount) MergeStorageUpdates(outAcc *OutputAccount) {
	if o.StorageUpdates == nil {
		o.StorageUpdates = make(map[string]*StorageUpdate)
	}
	for key, update := range outAcc.StorageUpdates {
		o.StorageUpdates[key] = update
	}
}

// GetFirstDataItem returns the first item from the Data field of a LogEntry
func (logEntry *LogEntry) GetFirstDataItem() []byte {
	if len(logEntry.Data) == 0 {
		return nil
	}
	return logEntry.Data[0]
}

// FormatLogDataForCall prepares Data field for a LogEntry
func FormatLogDataForCall(callType string, functionName string, functionArgs [][]byte) [][]byte {
	data := make([][]byte, 0)
	data = append(data, []byte(callType))
	data = append(data, []byte(functionName))
	data = append(data, functionArgs...)
	return data
}

// MaxLengthForValueToOptTransfer defines the maximum length for value to optimize cross shard transfer
const MaxLengthForValueToOptTransfer = 32
