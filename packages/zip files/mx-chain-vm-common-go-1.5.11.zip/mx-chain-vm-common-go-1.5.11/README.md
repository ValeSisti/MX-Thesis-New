<div style="text-align:center">
  <img src="https://raw.githubusercontent.com/multiversx/mx-chain-go/master/multiversx-logo.svg" alt="MultiversX"/>
</div>  

<br>

[![](https://img.shields.io/badge/made%20by-MultiversX-blue.svg?style=flat-square)](https://multiversx.com/)
[![](https://img.shields.io/badge/project-MultiversX%20Testnet-blue.svg?style=flat-square)](https://multiversx.com/)

# mx-chain-vm-common-go
Common structs between VM and node
