package txcache

const estimatedNumOfSweepableSendersPerSelection = 100

const senderGracePeriodLowerBound = 2

const senderGracePeriodUpperBound = 2

const numEvictedTxsToDisplay = 3
