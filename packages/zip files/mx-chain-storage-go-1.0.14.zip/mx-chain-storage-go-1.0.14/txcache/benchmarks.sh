#!/bin/bash
go test -bench="BenchmarkSendersMap_GetSnapshotAscending$" -benchtime=1x
