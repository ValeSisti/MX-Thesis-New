#include "../mxvm/context.h"

void answer() {
	int64finish(42);
}
