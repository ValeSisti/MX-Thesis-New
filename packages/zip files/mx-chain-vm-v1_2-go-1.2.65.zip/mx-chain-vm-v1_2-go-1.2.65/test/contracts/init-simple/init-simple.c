void int64finish(long long value);

void init() {
	int64finish(42);
}
