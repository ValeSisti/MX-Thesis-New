package nodepart

// Config is the configuration for the driver and for Node's part
type Config struct {
	MaxLoopTime int
}
