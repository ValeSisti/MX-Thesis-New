package common

// EnvVarVMPath is an environment variable
const EnvVarVMPath = "VM_PATH"
