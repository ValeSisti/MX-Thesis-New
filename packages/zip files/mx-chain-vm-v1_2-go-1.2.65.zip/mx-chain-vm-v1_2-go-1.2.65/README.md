# mx-chain-vm-v1_2-go

[![](https://img.shields.io/badge/made%20by-MultiversX-blue.svg)](http://multiversx.com/)
![Build](https://github.com/multiversx/mx-chain-vm-v1_2-go/actions/workflows/build-test.yml/badge.svg?branch=master)
[![Go Report Card](https://goreportcard.com/badge/multiversx/mx-chain-vm-v1_2-go)](https://goreportcard.com/report/multiversx/mx-chain-vm-v1_2-go)
[![LoC](https://tokei.rs/b1/github/multiversx/mx-chain-vm-v1_2-go?category=code)](https://github.com/multiversx/mx-chain-vm-v1_2-go)
[![codecov](https://codecov.io/gh/multiversx/mx-chain-vm-v1_2-go/branch/master/graph/badge.svg?token=MYS5EDASOJ)](https://codecov.io/gh/multiversx/mx-chain-vm-v1_2-go)

WASM-based Virtual Machine for running MultiversX Smart Contracts.
