from multiversx_sdk_cli.delegation.staking_provider import DelegationOperations

__all__ = ["DelegationOperations"]
