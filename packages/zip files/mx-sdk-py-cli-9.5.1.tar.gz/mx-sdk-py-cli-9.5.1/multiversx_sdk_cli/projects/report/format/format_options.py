class FormatOptions:
    def __init__(self, github_markdown: bool) -> None:
        self.github_flavor = github_markdown
