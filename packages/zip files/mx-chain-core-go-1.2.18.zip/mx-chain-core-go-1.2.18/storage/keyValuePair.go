package storage

// KeyValuePair is a tuple of (key, value)
type KeyValuePair struct {
	Key   []byte
	Value []byte
}
