package pubkeyConverter

var Prefix = bech32Config.prefix
