package data

// LogData holds the data needed for indexing logs and events
type LogData struct {
	LogHandler
	TxHash string
}
