package accounts

import "errors"

var errTokenNotFound = errors.New("token not found")
